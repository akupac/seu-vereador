#!/bin/bash

function pdf {
	./get_links.py http://projetos.camarapoa.rs.gov.br/processos/$1 | grep PROJETO         
}

for ((p=$1;p<=$2;p++)); do
	echo $p	
	FILE=$(pdf $p)
	if [ -n "$FILE" ]
	then	
		wget -O $p.pdf $FILE
		VERE=$(pdftotext $p.pdf - | grep "VEREADOR")
		VER=$(pdftotext $p.pdf - | grep "VER.")
		TAG=""
		if [ -n "$VERE" ] ; then TAG="$VERE" ; fi
		if [ -n "$VER" ] ; then TAG="$TAG $VER" ; fi
		if [ -n "$TAG" ] ; then mv $p.pdf "$p - $TAG.pdf"; fi
	fi
done
