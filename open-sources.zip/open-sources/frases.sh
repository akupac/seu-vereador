#!/bin/bash
frases=$(sed -n '/^   \*/,/^\*/{p;d};/^   \*/{p;q}' atas1.txt | grep -o \* | wc -l)
while [ $frases > 1 ]
do
	autor="$(awk '$1~/^\*/{if(f) exit; f=1} f' atas1.txt | awk -F'[*|:]' '{print $2}' | head -1)"
	awk '$1~/^\*/{if(f) exit; f=1} f' atas1.txt | sed 's|.*:\(.*\)|\1|' >> temp.txt #text
	cat temp.txt >> "$autor.txt"
	awk '$1~/^\*/{f++} !f||f>1' atas1.txt > temp.txt
	mv temp.txt "atas1.txt"
done
