for i in {41..60}
do
	j=$i*100
	n=$j+117000
	for k in {0..100}
	do
		l=$(($n+$k))		
		curl http://camarapoa.rs.gov.br/processos/$l | sed -n '/<dt>Processo:</,/<\/dl>/p' | perl -pne 's/\n//;' | perl -pne 's/            <dt>Processo:<\/dt>            <dd>/\n'$l'\t/;' | perl -pne 's/<\/dd>                        <dt>Data da Abertura:<\/dt>            <dd>/\t/;' | perl -pne 's/<\/dd>                        <dt>Autores<\/dt>            <dd>/\t/;' | perl -pne 's/<\/dd>                        <dt>Situação:<\/dt>            <dd>/\t/;' | perl -pne 's/<\/dd>                        <dt>Situação Plenária:<\/dt>            <dd>/\t/;' | perl -pne 's/<\/dd>                        <dt>Localização Atual:<\/dt>            <dd>/\t/;' | perl -pne 's/<\/dd>                        <dt>Última Tramitação:<\/dt>            <dd>/\t/;' | perl -pne 's/<\/dd>          <\/dl>/\t/;' >> projetos2.tsv
		
		lynx --dump --nonumbers http://camarapoa.rs.gov.br/processos/$l | grep -E '\.doc|\.docx|\.odt|\.rtf|\.txt|\.pdf' | perl -pne 's/\n/\t/;' >> projetos2.tsv 

	done
	


done
