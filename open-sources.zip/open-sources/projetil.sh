#!/bin/bash
#
# AMOSTRAS
# http://www.camarapoa.rs.gov.br/vereadores/airto-ferronato?page_projetos=1
# http://camarapoa.rs.gov.br/processos/.*
# ********
#
#primeiro lynx só vai fazer lista dos links dos projetos e fazer um txt com uma lista
# com a lista de links de projetos com tags html, sed com output tsv ($nome-vereador.tsv) para retirar números de processo (google: extrair texto entre tags)
# depois, algum commando para adicionar ao fim do arquivo tsv os links com a lista dos links
#
# input do usuário: vereador a ser buscado (nome parlamentar)
# ******** old *********
# wget --mirror --no-parent --convert-links -t3 -l=1 ./temp/teste-wget http://www.camarapoa.rs.gov.br/vereadores/airto-ferronato?page_projetos=1
# sed airt /"http://camarapoa.rs.gov.br/processos/111472"/ output.txt
# **********************************

vers=( "monica-leal" "joao-bosco-vaz" "claudio-janta" )

echo
	for i in "${vers[@]}"
do
	echo lynx --dump -nonumbers www.camarapoa.rs.gov.br/vereadores/airto-ferronato?page_projetos=2 | grep 'processos/' >> links-processos.txt
done



# array com o nome dos vereadores, de acordo com a URL do site (/$vereador?page_projetos=##)



#cria a lista de links SEM AS TAGS e vai adicionando os novos links na mesma lista:
#lynx --dump -nonumbers www.camarapoa.rs.gov.br/vereadores/airto-ferronato?page_projetos=2 | grep 'processos/' >> links-processos.txt

#cria a lista de links COM AS TAGS e vai adicionando os novos links na mesma lista:
#lynx --source -nonumbers www.camarapoa.rs.gov.br/vereadores/airto-ferronato?page_projetos=2 | grep 'processos/' 	| sed 's/<strong>/\t' >> links-processos-source.txt

# Formata deste arquivo acima para tsv apenas com as informações necessárias
#	ver.1: 
#
#	ver.2: sed 's/\t*.*href="\(.*\)">/\t\1\t/g' links-processos-source.txt > output-test.txt
#
#tmp:
#
#
#
#
#baixa da lista de arquivos
#	wget --input-file=lista-links.txt
#
#
# monta estrutura de pastas do site wget -r -x --no-remove-listing --spider ftp://ftp.example.com/
# é bom, mas nao usei http://www.hardware.com.br/dicas/baixando-sites-wget.html
# http://www.linuxquestions.org/questions/linux-general-1/lynx-grep-variable-868286/
# http://linux.die.net/man/1/lynx
# https://www.gnu.org/software/wget/manual/wget.html
