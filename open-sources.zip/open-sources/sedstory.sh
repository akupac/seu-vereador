#!/bin/bash
mat=('   ' '\t' '\. ' 'Sr\t' 'Sra\t' 'Sras\t' 'Srs\t' 'Av\t' 'Ex\t' 'art\t' 'Dra\t' 'Dr\t' 'Ver\t' 'Exa\t' 'V\t');
sub=('' '' '\t' 'Sr. ' 'Sra. ' 'Sras. ' 'Srs. ' 'Av. ' 'Ex. ' 'art. ' 'Dra. ' 'Dr. ' 'Ver. ' 'Exa. ' 'V. ');

cat $1 > temp.txt; cnt=0; for i in "${mat[@]}"; do
	subber=${sub[$cnt]}
	sed "s/$i/$subber/g" temp.txt > $2; cat $2 > temp.txt
	let "cnt = cnt + 1"; done

sed ':a;N;$!ba;s/\n/ /g' temp.txt > $2; rm temp.txt | 

# executar o script como segue: "./sedstory #arquivo_de_entrada #arquivo_de_saida"
# ex: "./sedstory.sh fmc.txt out.csv"

#tr '\t' '\n' < out.txt > saidateste.txt
#substitui TAB por NOVALINHA

#sed "s/^.*$/\['&'\],/g" saidateste.txt >> out-tri.txt
# adiciona texto no início e no fim da linha


